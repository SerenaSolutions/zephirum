# ZYQL — MATRIZ DE CONFORMIDADE (especificação v1.3 × código × evidência)
Emitida 12/10/2026 · Base: auditoria direta de /tmp/zeph_repo (c-api/zyql.c 457 linhas, zyql.h 63 linhas, docs/SECURITY.md, HYBRID_BOUNDARY_PATTERN.md) e do libzyql 0.1.0 · ZYQL v0.4 (núcleo da Solene).
Rótulos: IMPLEMENTADO · EXPERIMENTAL · ESPECIFICAÇÃO · BLOQUEADO. Nada abaixo é promovido sem evidência apontável.

## A. DUAS BASES DE CÓDIGO QUE NÃO SÃO A MESMA (achado nº 1, severidade ALTA)
| | libzyql da Solene (zyql_c_api.c) | c-api do repo público (c-api/zyql.c) |
|---|---|---|
| Foco | semântica quântica + IR de circuito + portões de despacho | decisão trivalente + recibo + portão por propósito |
| Hash | sem SHA próprio (hashes feitos fora, Python) | SHA-256 próprio em C (zyql_sha256_hex) |
| Recibo/REFUSED | não existe | existe (REFUSED_BEFORE_COMPUTE, zyql_gate_circuit, zyql_verify_receipt) |
| Assinatura ML-DSA-44 | não existe | declarada em docs/SECURITY.md:16 |
| Hoeffding | não existe | citado em 3 docs; implementação em C não localizada por mim em c-api/zyql.c |
**Recomendação:** o v1.3 descrito na mensagem é a c-api do repo. O libzyql da Solene é outro componente (IR/QASM3/portões). Definir qual é o "kernel oficial" e como os dois se unem é decisão do Arquiteto-Chefe.

## B. MATRIZ FASE × ESTADO
| Fase | Afirmação do esqueleto | Evidência que EU verifiquei | Estado atribuído |
|---|---|---|---|
| 0 Portão | recusa por propósito proibido ANTES de executar | c-api/zyql.c:301-307 emite REFUSED_BEFORE_COMPUTE, answer=-1; zyql_purpose_class exportado | IMPLEMENTADO (código existe); teste reproduzível por mim: PENDENTE |
| 0 Recibo prévio ML-DSA-44 | assinar declaração/propósito | só a citação em SECURITY.md; assinatura não localizada em zyql.c (só SHA-256) | PENDENTE DE VERIFICAÇÃO (pode estar fora do C) |
| 1 Avaliar | clássica→análise lexical; quântica→transpilar | zyql_decide existe; ladder ZCA documentada | IMPLEMENTADO (clássico); EXPERIMENTAL (quântico) |
| 2 Execução | só computação, zero I/O | NENHUMA evidência de imposição arquitetural (sandbox, seccomp, ausência de syscalls) | **BLOQUEADO como alegação**: comentário no código não é propriedade imposta |
| 2 QPU | ibm_fez, paridade 4/4 | meus jobs reais ibm_fez/marrakesh confirmam o hardware; a paridade 4/4 do outro agente não tenho como reproduzir | EXPERIMENTAL |
| 3 Hoeffding | ε=√(ln(2/δ)/2S), regra 0.5±ε | fórmula correta como limite de proporção; vínculo ao evento de erro NÃO formalizado (ver §C) | EXPERIMENTAL; garantia "P(erro)≤δ" BLOQUEADA até formalizar |
| 4 Cadeia pre→pos + ledger | encadeamento e imutabilidade | recibo tem hash; ledger "imutável" sem mecanismo externo de ancoragem | EXPERIMENTAL; "imutável" BLOQUEADO |
| Sintaxe (qbit, ←, qif, portão ⟨\|⟩) | linguagem completa | parser não conectado (declarado pelo próprio outro agente) | ESPECIFICAÇÃO |
| T1 no-clone pelo tipo | próximo a compilar | zyql_qubit_clone da Solene dá E_NOCLONE em RUNTIME; checagem por tipo estático não existe | ESPECIFICAÇÃO (runtime: IMPLEMENTADO no libzyql) |

## C. HOEFFDING — O QUE A FÓRMULA PROVA E O QUE NÃO PROVA (tarefa do Exec. 1; refutação do Exec. 3)
Fato matemático: para S amostras i.i.d. Bernoulli(p), P(|p̂−p| ≥ ε) ≤ 2·exp(−2Sε²). Fixando ε=√(ln(2/δ)/(2S)) obtém-se P(|p̂−p| ≥ ε) ≤ δ. Esse é o ÚNICO conteúdo provado pela fórmula.
Lacunas que a "garantia formal P(erro)≤δ" precisa fechar antes de ser anunciada:
1. **Evento de erro não definido.** O veredito é 0, 1 ou REFUSED por p̂ vs 0.5±ε. O "erro" precisa ser definido sobre p (verdadeiro), não p̂: ex.: erro = emitir 0 quando p<0.5. Então p̂>0.5+ε com p<0.5 exige p̂−p>ε, com prob ≤ δ/2 (unilateral). Isso funciona SE o rótulo "verdade" for p vs 0.5.
2. **Hipótese i.i.d.** não vale automaticamente em hardware: deriva de calibração entre tiros (documentada nas minhas FRONTIER 001-003) viola independência/estacionariedade. Hoeffding valida a estatística de amostragem, não o erro sistemático do dispositivo.
3. **Viés sistemático.** O QPU mede p_hw ≠ p_ideal (ruído). O limite protege p_hw, não p_ideal. Conferir que o veredito é sobre p_hw ou incluir termo de viés calibrado.
4. **Zona REFUSED** (|p̂−0.5|≤ε) cobre a incerteza; o ganho de honestidade é real (não força decisão), mas a taxa de REFUSED cresce com ε grande/S pequeno.
5. **Múltiplos vereditos:** δ por decisão, não por sessão; N decisões exigem correção (Bonferroni/Holm) se a alegação for conjunta.
**Parecer:** fórmula correta e útil; frase "garantia formal" BLOQUEADA até (1)-(3) estarem escritos no recibo (δ, evento, hipótese i.i.d., viés).
Tarefa de teste adversarial (Exec. 3): simular p=0.5±pequeno com deriva e medir taxa de erro real vs δ.

## D. ML-DSA-44 — O QUE ASSINATURA NÃO GARANTE (tarefa do Exec. 1+3)
Escopo: autenticidade/integridade do recibo. Não garante: verdade do conteúdo, legitimidade do signatário, imutabilidade do ledger, ausência de replay, resistência do sistema inteiro.
Lacunas a especificar: (a) identidade do signatário e registro da chave pública; (b) proteção da chave privada (onde vive, quem acessa); (c) **prevenção de replay**: nonce/sequência monotônica no recibo + janela; (d) versionamento do esquema; (e) revogação de chave; (f) **ancoragem do ledger** (hash-chain sozinha não é imutável: precisa de testemunha externa/timestamp).
Observação de proveniência: meu pré-registro (hypotheses_*.json + .cert com SHA-256) é cadeia local sem assinatura de terceiros; serve de evidência temporal só mediante commit público (já feito no GitHub, que atua como testemunha de data).

## E. "ZERO I/O" NA FASE 2 (achado nº 2, severidade ALTA)
Para ser propriedade e não comentário: (i) executor em processo separado sem rede/arquivo (seccomp/namespace, ou módulo sem libc de I/O); (ii) teste negativo: tentar open()/socket() dentro da fase e ver falha; (iii) auditoria de link (nm/objdump) mostrando ausência de símbolos de I/O no módulo de execução. Nenhum dos três foi evidenciado.

## F. PRIMEIRA MISSÃO CONJUNTA (recomendação do documento, aceita) — DEFINIÇÃO DE PRONTO
1. Arq.: congelar a spec v1.3 (um arquivo versionado) incluindo evento de erro de Hoeffding e esquema do recibo (nonce, versão, δ, S, hipóteses).
2. Eng.: build reproduzível da c-api; rodar test_c_api.c/test_bridge.c/parity_nexa.py e registrar saída; implementar apenas a regra aprovada.
3. Ver.: testes negativos (Hoeffding com deriva, recibo adulterado, replay, recibo sem prévio, "zero I/O"); relatório de achados com severidade.
4. Diretor humano aprova ou bloqueia (decisão registrada).
Pacote de evidências por entrega: versão, commit, ambiente, comando, resultado, logs, parecer do revisor.

## G. DECISÕES EM ABERTO PARA O DIRETOR
1. "Zykio" é nome novo do motor ou é o ZYQL? (a mensagem pergunta; eu assumi ZYQL).
2. Unificar libzyql (Solene: IR/portões) com c-api (repo: recibo/REFUSED) ou mantê-los como camadas separadas?
3. O arquivo `editora/projetos/zeal/TEOREMA-SINTAXE.md` citado na mensagem NÃO existe no meu sandbox nem no repo público; preciso dele (ou da cópia) para revisar os 6 teoremas T1-T6.
